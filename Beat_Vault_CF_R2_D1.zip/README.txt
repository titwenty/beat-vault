BEAT VAULT — CLOUDFLARE R2 + D1
=================================

Это уже НЕ локальная демка:
- D1 хранит проекты, BPM, коды и метаданные.
- R2 хранит MP3/WAV и .FLP.
- Pages Functions дают API.
- Артист может зайти с другого телефона/ПК и увидеть те же проекты.
- Код проекта проверяется на сервере.
- После проверки выдаётся временный URL для аудио/FLP.

ВАЖНО: Cloudflare Functions нельзя развернуть обычным Direct Upload из панели Pages.
Для этой версии используй Wrangler/CLI или Git deployment.

1. Установи Node.js LTS.

2. В этой папке:
   npm install

3. Войди в Cloudflare:
   npx wrangler login

4. Создай R2 bucket:
   npx wrangler r2 bucket create beat-vault-media

5. Создай D1:
   npx wrangler d1 create beat-vault-db

   Команда покажет database_id.
   Открой wrangler.jsonc и вставь этот ID вместо:
   PASTE_YOUR_D1_DATABASE_ID_HERE

6. Создай таблицу:
   npx wrangler d1 execute beat-vault-db --remote --file=schema.sql

7. Задай пароль админки:
   npx wrangler pages secret put ADMIN_PASSWORD

   Введи свой пароль. Не пиши его в wrangler.jsonc.

8. Создай секрет для временных ссылок R2:
   npx wrangler pages secret put MEDIA_TOKEN_SECRET

   Введи длинную случайную строку.

9. Деплой:
   npx wrangler pages deploy public

   Если твой Cloudflare Pages проект уже создан и хочешь деплоить Functions через Pages:
   используй Git deployment или соответствующий Pages deployment workflow с этим репозиторием/папкой.
   После первого деплоя проверь Settings -> Functions -> Bindings, что D1 = DB и R2 = MEDIA.

СТРУКТУРА:
public/index.html        — сайт
functions/api/...        — серверный API
schema.sql               — структура D1
wrangler.jsonc           — bindings D1/R2
package.json             — Wrangler

АДМИН:
Нажми ADMIN на сайте и введи ADMIN_PASSWORD.

ВРЕМЕННЫЕ ССЫЛКИ:
После правильного кода проекта сервер выдаёт подписанные ссылки на R2 примерно на 1 час.

АРТИСТ:
Видит список проектов -> вводит код проекта -> слушает бит -> может скачать FLP.

БЕЗОПАСНОСТЬ:
Не используй пароль "admin" в production.
Пароль хранится как Cloudflare secret.
Не публикуй wrangler.jsonc с реальным секретом.

ОГРАНИЧЕНИЕ:
Изменение BPM сейчас сделано через playbackRate браузера, поэтому при изменении скорости меняется и высота звука. Для поведения как FL Studio нужен отдельный pitch-preserving time-stretch.
