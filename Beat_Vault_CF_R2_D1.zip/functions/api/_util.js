export async function requireAdmin(request, env) {
  const expected = env.ADMIN_PASSWORD;
  const got = request.headers.get("X-Admin-Password") || "";
  if (!expected || got !== expected) return new Response(JSON.stringify({error:"Неверный пароль администратора"}), {status:401, headers:{"content-type":"application/json"}});
  return null;
}
export function json(data,status=200,extra={}) {
  return new Response(JSON.stringify(data), {status, headers:{"content-type":"application/json", ...extra}});
}
export function safeName(name){return String(name||"file").replace(/[^a-zA-Z0-9._-]+/g,"_").slice(0,120)}
export function mime(name, fallback="application/octet-stream"){
 const n=String(name||"").toLowerCase();
 if(n.endsWith(".mp3"))return "audio/mpeg"; if(n.endsWith(".wav"))return "audio/wav"; if(n.endsWith(".m4a"))return "audio/mp4"; if(n.endsWith(".ogg"))return "audio/ogg"; if(n.endsWith(".flac"))return "audio/flac"; if(n.endsWith(".aac"))return "audio/aac"; if(n.endsWith(".flp"))return "application/octet-stream"; return fallback;
}
function b64u(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
function ub64u(s){s=s.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
async function hmac(secret,data){
 const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign","verify"]);
 return crypto.subtle.sign("HMAC",key,new TextEncoder().encode(data));
}
export async function signToken(env,key,exp){
 const body=btoa(unescape(encodeURIComponent(JSON.stringify({k:key,e:exp}))));
 const sig=b64u(await hmac(env.MEDIA_TOKEN_SECRET,body));
 return body+"."+sig;
}
export async function verifyToken(env,token,key){
 try{
  const [body,sig]=String(token||"").split(".");
  if(!body||!sig)return false;
  const data=JSON.parse(decodeURIComponent(escape(atob(body))));
  if(data.k!==key || Number(data.e||0)<Math.floor(Date.now()/1000))return false;
  const expected=await hmac(env.MEDIA_TOKEN_SECRET,body);
  const got=ub64u(sig);
  if(expected.byteLength!==got.byteLength)return false;
  return crypto.subtle.timingSafeEqual?crypto.subtle.timingSafeEqual(expected,got):Array.from(new Uint8Array(expected)).every((v,i)=>v===got[i]);
 }catch{return false}
}