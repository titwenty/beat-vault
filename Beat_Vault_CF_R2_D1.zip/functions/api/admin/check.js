import {json,requireAdmin} from "../_util.js";
export async function onRequestGet({request,env}) {
  const denied=await requireAdmin(request,env); if(denied)return denied;
  return json({ok:true});
}