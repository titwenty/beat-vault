import {verifyToken} from "./_util.js";
export async function onRequestGet({request,env}) {
  const u=new URL(request.url), key=u.searchParams.get("key"), token=u.searchParams.get("t");
  if(!key || !(await verifyToken(env,token,key)))return new Response("Forbidden",{status:403});
  const obj=await env.MEDIA.get(key); if(!obj)return new Response("Not found",{status:404});
  const headers=new Headers();obj.writeHttpMetadata(headers);headers.set("etag",obj.httpEtag);headers.set("cache-control","private, max-age=3600");
  return new Response(obj.body,{headers});
}