import {json,signToken} from "../../_util.js";
export async function onRequestPost({request,env,params}) {
  let body={}; try{body=await request.json()}catch{}
  const row=await env.DB.prepare("SELECT id,name,bpm,key,note,audio_key,flp_key,code FROM projects WHERE id=?").bind(params.id).first();
  if(!row)return json({error:"Проект не найден"},404);
  if(String(body.code||"")!==String(row.code))return json({error:"Неверный код проекта"},403);
  const exp=Math.floor(Date.now()/1000)+3600;
  const audioToken=await signToken(env,row.audio_key,exp);
  const flpToken=row.flp_key?await signToken(env,row.flp_key,exp):null;
  const base=new URL(request.url).origin;
  return json({
    project:{id:row.id,name:row.name,bpm:row.bpm,key:row.key,note:row.note},
    audioUrl:`${base}/api/media?key=${encodeURIComponent(row.audio_key)}&t=${encodeURIComponent(audioToken)}`,
    flpUrl:flpToken?`${base}/api/media?key=${encodeURIComponent(row.flp_key)}&t=${encodeURIComponent(flpToken)}`:null
  });
}