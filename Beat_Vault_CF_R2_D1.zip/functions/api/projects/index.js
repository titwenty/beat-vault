import {json} from "../_util.js";
export async function onRequestGet({env}) {
  const {results}=await env.DB.prepare("SELECT id,name,bpm,key,note,created_at,flp_key FROM projects ORDER BY created_at DESC").all();
  return json({projects:results});
}