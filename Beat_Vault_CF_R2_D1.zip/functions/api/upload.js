import {json,requireAdmin,safeName,mime} from "./_util.js";
export async function onRequestPost({request,env}) {
  const denied=await requireAdmin(request,env); if(denied)return denied;
  const form=await request.formData();
  const audio=form.get("audio"), flp=form.get("flp");
  const name=String(form.get("name")||"").trim(), code=String(form.get("code")||"");
  const bpm=Number(form.get("bpm")||145), key=String(form.get("key")||""), note=String(form.get("note")||"");
  if(!name||!code||!(audio instanceof File))return json({error:"Название, код и аудиофайл обязательны"},400);
  const id=crypto.randomUUID(), audioKey=`audio/${id}-${safeName(audio.name)}`;
  await env.MEDIA.put(audioKey,audio.stream(),{httpMetadata:{contentType:mime(audio.name,"audio/mpeg"),contentDisposition:"inline"}});
  let flpKey=null;
  if(flp instanceof File && flp.size){flpKey=`flp/${id}-${safeName(flp.name)}`;await env.MEDIA.put(flpKey,flp.stream(),{httpMetadata:{contentType:mime(flp.name),contentDisposition:`attachment; filename="${safeName(flp.name)}"`}})}
  await env.DB.prepare("INSERT INTO projects (id,name,code,bpm,key,note,audio_key,flp_key,created_at) VALUES (?,?,?,?,?,?,?,?,datetime('now'))")
    .bind(id,name,code,bpm,key,note,audioKey,flpKey).run();
  return json({ok:true,id});
}