CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  bpm INTEGER NOT NULL DEFAULT 145,
  key TEXT DEFAULT '',
  note TEXT DEFAULT '',
  audio_key TEXT NOT NULL,
  flp_key TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_projects_created_at ON projects(created_at);
